<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BHC Noon Meals Scheme</title>
    <link rel="icon" type="image/x-icon" href="images/user.jpg">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family:'Merriweather', sans-serif ;
            margin: 0;
            padding: 0;
        }
        footer {
            font-family:'Merriweather', sans-serif ;
            background-color: #06557c;
            color: #ffffff;
            padding: 20px 0;
            position:relative;
        }

        .footer-container {
            display:flex;
            justify-content: space-around;
            flex-wrap: wrap;
            text-align:left;
            padding: 0 20px;
            position: relative;
        }

        .footer-section {
            background-color:  #06557c;
            flex: 1;
            margin: 10px;
            min-width: 200px;
            font-family:'Merriweather', sans-serif';
            
        }

        .footer-section h4 {
            font-size: 18px;
            margin-bottom: 10px;
            border-bottom: 2px #ffffff;
           font-family:'Merriweather', sans-serif' ;
        }

        .footer-section p,
        .footer-section ul {
            font-size: 15px;
            margin: 0;
            padding: 0;
        }

        .social-icons {
            display: flex;
            gap: 10px;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 10px;
            border-top: 1px solid #ffffff;
            font-size: 14px;
        }
        .navbar {
    font-family:'Merriweather', sans-serif ;
    background-color: #ffffff;
    border-bottom: 2px solid #ccc;
    padding: 20px 20px;
    display:flex;
    justify-content:center;
}
.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    text-decoration: none;
    color: #333;
    font-size: 16px;
}

.nav-links a:hover {
    color: #ff5722;
}
.logo
{
    margin-left: 5px;
    justify-content:left;

}
.nav-links a.active {
    color: #ff5722; 
    border-bottom: 2px solid #ff5722;
    font-weight: bold;
}
/* Navbar Styles */
.nav-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}



.nav-logo {
    height: 60px;
    width: auto;
    margin-right: 10px;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    font-family:'Merriweather', sans-serif ;
    text-decoration: none;
    color: #333;
    font-size: 16px;
    padding: 5px 10px;
}

.nav-links a.active {
    font-family:'Merriweather', sans-serif ;
    color: #ff5722; 
}
.container {
            max-width: 700px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 24px;
            color: #06557c;
        }

        .header p {
            font-size: 16px;
            color: #666;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        input[type="radio"], input[type="checkbox"] {
            margin-right: 10px;
        }

        .rating {
            display: flex;
            gap: 10px;
        }

        button {
            display: block;
            width: 100%;
            background-color: #06557c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #06557c;
        }

    </style>
</head>
<body>
    <nav class="navbar">
           <a href="home.php" class="logo">
            <img src="images/nav-logo.png" alt="Logo" class="nav-logo">
        </a>
        <ul class="nav-links">
            <li><a href="student_home.php">HOME</a></li>
            <li><a href="menu.php">MENU</a></li>
            <li><a href="notification.php ">NOTIFICATION</a></li>
            <li><a href="eligibility.php">ELIGIBILITY</a></li>
            <li><a href="feedback.php">FEEDBACK</a></li>
            <li><a href="home.php">LOGOUT</a></li>
            <li>
                <a href="profile.html">
                    <img src="images/user-trust (1).png">
                   
                </a>
            </li>
        </ul>

    </nav>
    <div class="container">
        <div class="header">
            <h1>Your Feedback Matters!</h1>
            <p>Help us improve by sharing your thoughts. This form will take only 2 minutes of your time!</p>
        </div>
        <form id="feedbackForm">
            <div class="form-group">
                <label>1. How would you rate your overall experience with our food services?</label>
                <label><input type="radio" name="experience" value="Excellent"> Excellent 😊</label>
                <label><input type="radio" name="experience" value="Good"> Good 🙂</label>
                <label><input type="radio" name="experience" value="Neutral"> Neutral 😐</label>
                <label><input type="radio" name="experience" value="Poor"> Poor 😞</label>
            </div>
            <div class="form-group">
                <label>2. What did you like the most about our food services?</label>
                <textarea name="likeMost" rows="3" placeholder="Your answer..."></textarea>
            </div>
            <div class="form-group">
                <label>3. What can we improve to make your dining experience better?</label>
                <textarea name="improve" rows="3" placeholder="Your answer..."></textarea>
            </div>
            <div class="form-group">
                <label>4. How would you rate the variety of dishes available?</label>
                <div class="rating">
                    <label><input type="radio" name="variety" value="1"> ⭐</label>
                    <label><input type="radio" name="variety" value="2"> ⭐⭐</label>
                    <label><input type="radio" name="variety" value="3"> ⭐⭐⭐</label>
                    <label><input type="radio" name="variety" value="4">⭐⭐⭐⭐</label>
                    <label><input type="radio" name="variety" value="5"> ⭐⭐⭐⭐⭐</label>
                </div>
            </div>
            <div class="form-group">
                <label>5. Would you recommend our food services to others?</label>
                <label><input type="radio" name="recommend" value="Yes"> Yes, absolutely! 👍</label>
                <label><input type="radio" name="recommend" value="Maybe"> Maybe 🤔</label>
                <label><input type="radio" name="recommend" value="No"> No 👎</label>
            </div>
            <div class="form-group">
                <label>6. Did you encounter any issues or challenges with our food services? If yes, please elaborate.</label>
                <textarea name="issues" rows="3" placeholder="Your answer..."></textarea>
            </div>
            <div class="form-group">
                <label>7. What new dishes or cuisines would you like us to add in the future?</label>
                <textarea name="features" rows="3" placeholder="Your answer..."></textarea>
            </div>
            <div class="form-group">
                <label>8. Any other comments or feedback regarding our food services?</label>
                <textarea name="comments" rows="3" placeholder="Your answer..."></textarea>
            </div>
            <button type="submit">🚀 Submit Feedback!</button>
        </form>
    </div>


    <script>
        document.getElementById('feedbackForm').addEventListener('submit', function(event) {
            event.preventDefault();
            alert('Thank you for your feedback!');
            this.reset();
        });
    </script>

    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Bishop Heber College</h4>
                <p>Post Box No. 615,<br>
                   Tiruchirappalli - 620 017<br>
                   Tamil Nadu, South India.</p>
                <p>Phone: 0431 - 2770136<br>
                   Fax: 0431 - 2770293<br>
                   Email: <a href="mailto:principal@bhc.edu.in" style="color: #ffffff">principal@bhc.edu.in</a></p>
            </div>
            <div class="footer-section">
                <h4>Our Social Networks</h4>
                <div class="social-icons">
                    <!-- Add your social media links -->
                    <a href="https://www.facebook.com/bishophebercollegeofficial"><img src="https://cdn-icons-png.flaticon.com/128/5968/5968764.png" alt="Facebook" width="20"></a>
                    <a href="https://twitter.com/Heber_Tweets?s=08"><img src="https://cdn-icons-png.flaticon.com/128/5969/5969020.png" alt="Twitter" width="20"></a>
                    <a href="https://www.youtube.com/channel/UCLdStGHBVRnwMXSXW21-BSQ"><img src="https://cdn-icons-png.flaticon.com/128/1384/1384060.png" alt="Youtube" width="20"></a>
                    <a href="https://www.instagram.com/heber_official"><img src="https://cdn-icons-png.flaticon.com/128/1384/1384063.png" alt="Instagram" width="20"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Bishop Heber College. All Rights Reserved.</p>
        </div>
    </footer>
    <script>const currentUrl = window.location.pathname.split('/').pop();

// Get all navigation links
const navLinks = document.querySelectorAll('.nav-links a');

// Loop through links to match the URL and add the 'active' class
navLinks.forEach(link => {
    if (link.getAttribute('href') === currentUrl) {
        link.classList.add('active');
    }
});</script>
    <script src="script.js"></script>
</body>
</html>