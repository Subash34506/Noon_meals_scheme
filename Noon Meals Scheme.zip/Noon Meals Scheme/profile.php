<?php
session_start();
if (!isset($_SESSION['roll_number'])) {
    header("Location: student_login.php");
    exit();
}
$roll_number = $_SESSION['roll_number'];
$conn = new mysqli('localhost', 'root', '', 'noon_meals');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$query = "SELECT * FROM student_login WHERE roll_number ='$roll_number'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    echo "No data found for the given roll number.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BHC Noon Meals Scheme</title>
    <style>
         body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
        }
        footer {
            font-family:'Merriweather', sans-serif ;
            background-color: #06557c;
            color: #ffffff;
            padding: 20px 0;
            position:relative;
        }

        .footer-container {
            display:flex;
            justify-content: space-around;
            flex-wrap: wrap;
            text-align:left;
            padding: 0 20px;
            position: relative;
        }

        .footer-section {
            background-color:  #06557c;
            flex: 1;
            margin: 10px;
            min-width: 200px;
            font-family:'Merriweather', sans-serif';
            
        }

        .footer-section h4 {
            font-size: 18px;
            margin-bottom: 10px;
            border-bottom: 2px #ffffff;
           font-family:'Merriweather', sans-serif' ;
        }

        .footer-section p,
        .footer-section ul {
            font-size: 15px;
            margin: 0;
            padding: 0;
        }

        .social-icons {
            display: flex;
            gap: 10px;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 10px;
            border-top: 1px solid #ffffff;
            font-size: 14px;
        }
        .navbar {
    font-family:'Merriweather', sans-serif ;
    background-color: #ffffff;
    border-bottom: 2px solid #ccc;
    padding: 20px 20px;
    display:flex;
    justify-content:center;
}
.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    text-decoration: none;
    color: #333;
    font-size: 16px;
}

.nav-links a:hover {
    color: #ff5722;
}
.logo
{
    margin-left: 5px;
    justify-content:left;

}
.nav-links a.active {
    color: #ff5722; 
    border-bottom: 2px solid #ff5722;
    font-weight: bold;
}
/* Navbar Styles */
.nav-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}



.nav-logo {
    height: 60px;
    width: auto;
    margin-right: 10px;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    font-family:'Merriweather', sans-serif ;
    text-decoration: none;
    color: #333;
    font-size: 16px;
    padding: 5px 10px;
}

.nav-links a.active {
    font-family:'Merriweather', sans-serif ;
    color: #ff5722; 
}
.container {
    font-family: 'Poppins', sans-serif;
    width: 80%; /* Responsive width */
    max-width: 600px; /* Limit the width */
    height: auto; /* Dynamic height based on content */
    margin: 0 auto; /* Center align the container */
    background-color: white;
    padding: 30px; /* Increased padding for better spacing */
    border-radius: 10px;
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2); /* Enhanced shadow for depth */
    box-sizing: border-box; /* Include padding in dimensions */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.container:hover {
    transform: translateY(-10px); /* Lift effect */
    box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.3); /* Deeper shadow on hover */
}

.section-title{
    justify-self: center;
    font-family: 'Merriweather', sans-serif;
}
        .section-title h2 {
    font-size: 32px;
    font-weight: 700;
    position: relative;
    justify-content: center;
    color:#2b2320;
    font-family: 'Merriweather', sans-serif;
}
.section-title h2:before {
    margin: 0 15px 10px 0;
}
.section-title h2:after {
    margin:  0 0 10px 15px;
}
.section-title h2:before, .section-title h2:after {
    content: "";
    width: 50px;
    height: 2px;
    background: #f03c02;
    display: inline-block;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
    font-family: 'Merriweather', sans-serif;
}

@keyframes slide-in {
    from {
        width: 0;
    }
    to {
        width: 50px;
    }
}

form {
    display: flex;
    flex-direction: column; /* Stack elements vertically */
    gap: 15px; /* Spacing between elements */
    animation: fade-in 1s ease-out;
}

@keyframes fade-in {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

label {
    font-weight: bold; /* Make labels stand out */
    margin-top: 10px;
    transition: color 0.3s ease;
}

label:hover {
    color:  #06557c; /* Change color on hover */
}

input, textarea {
    font-family: 'Poppins', sans-serif;
    width: 100%; /* Ensure inputs take full container width */
    padding: 12px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box; /* Consistent box model */
    transition: box-shadow 0.3s ease, border-color 0.3s ease;
}

input:focus, textarea:focus {
    border-color:  #06557c;
    box-shadow: 0 0 5px  #06557c(0, 102, 204, 0.5);
}

button {
    width: 100%; /* Full width button */
    padding: 12px;
    background-color:  #06557c;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
    position: relative;
    overflow: hidden;
}

button:hover {
    background-color:  #06557c;
    transform: scale(1.05); /* Slightly enlarge button on hover */
}

button::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.3);
    opacity: 0;
    transition: opacity 0.3s ease;
}

button:hover::after {
    opacity: 1; /* Highlight effect */
}

#profile-pic {
    display: block;
    margin: 0 auto 15px;
    border-radius: 50%;
    width: 150px;
    height: 150px;
    object-fit: cover;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15); /* Softer shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

#profile-pic:hover {
    transform: scale(1.1); /* Enlarge slightly on hover */
    box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.3); /* Deeper shadow */
}

.profile-pic-label {
    text-align: center;
    margin-bottom: 10px;
    font-weight: bold;
    color: #333;
}

.profile-section {
    margin-bottom: 30px;
}

    </style>
</head>
<body>
<nav class="navbar">
           <a href="home.php" class="logo">
            <img src="images/nav-logo.png" alt="Logo" class="nav-logo">
        </a>
        <ul class="nav-links">
            <li><a href="student_home.php">HOME</a></li>
            <li><a href="menu.php">MENU</a></li>
            <li><a href="notification.php ">NOTIFICATION</a></li>
            <li><a href="eligibility.php">ELIGIBILITY</a></li>
            <li><a href="feedback.php">FEEDBACK</a></li>
            <li><a href="home.php">LOGOUT</a></li>
            <li>
                <a href="profile.html">
                    <img src="images/user-trust (1).png">
                   
                </a>
            </li>
        </ul>

    </nav>
    
<br>
<br>
<br>
<br>

    <div class="container">
    <div class="section-title">
        <h2>Student Profile</h2>
    </div>

        <!-- Profile Picture Section -->
        <div class="profile-section">
           <center> <label id="profile-pic-label">Profile Picture</label></center>
            <img id="profile-pic" src="default-profile.png" alt="Profile Picture">
            <input type="file" id="profile-pic-upload" accept="image/*">
        </div>

        <!-- Farmer Details Form -->
        <form id="farmerProfileForm">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" placeholder="Enter your full name" required>
            </div>

            <div class="form-group">
                <label for="contact">Contact Number</label>
                <input type="tel" id="contact" placeholder="Enter your contact number" required>
            </div>

            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" id="location" placeholder="Enter your farm location" required>
            </div>

            <div class="form-group">
                <label for="bio">Short Bio</label>
                <textarea id="bio" placeholder="Write a short bio about yourself"></textarea>
            </div>

            <div class="form-group">
                <button type="submit">Save Profile</button>
            </div>
        </form>
    </div>

    
    <br>
<br>
<br>
<br>


    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Bishop Heber College</h4>
                <p>Post Box No. 615,<br>
                   Tiruchirappalli - 620 017<br>
                   Tamil Nadu, South India.</p>
                <p>Phone: 0431 - 2770136<br>
                   Fax: 0431 - 2770293<br>
                   Email: <a href="mailto:principal@bhc.edu.in" style="color: #ffffff">principal@bhc.edu.in</a></p>
            </div>
            <div class="footer-section">
                <h4>Our Social Networks</h4>
                <div class="social-icons">
                    <!-- Add your social media links -->
                    <a href="https://www.facebook.com/bishophebercollegeofficial"><img src="https://cdn-icons-png.flaticon.com/128/5968/5968764.png" alt="Facebook" width="20"></a>
                    <a href="https://twitter.com/Heber_Tweets?s=08"><img src="https://cdn-icons-png.flaticon.com/128/5969/5969020.png" alt="Twitter" width="20"></a>
                    <a href="https://www.youtube.com/channel/UCLdStGHBVRnwMXSXW21-BSQ"><img src="https://cdn-icons-png.flaticon.com/128/1384/1384060.png" alt="Youtube" width="20"></a>
                    <a href="https://www.instagram.com/heber_official"><img src="https://cdn-icons-png.flaticon.com/128/1384/1384063.png" alt="Instagram" width="20"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Bishop Heber College. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        document.getElementById('profile-pic-upload').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profile-pic').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        document.getElementById('farmerProfileForm').addEventListener('submit', function(event) {
            event.preventDefault();

            const name = document.getElementById('name').value;
            const contact = document.getElementById('contact').value;
            const location = document.getElementById('location').value;
            const bio = document.getElementById('bio').value;
            const profilePic = document.getElementById('profile-pic').src;

            const farmerProfile = {
                name,
                contact,
                location,
                bio,
                profilePic
            };

            // Save farmer profile to localStorage (or any backend if applicable)
            localStorage.setItem('farmerProfile', JSON.stringify(farmerProfile));

            alert('Profile saved successfully!');
        });

        // Load saved profile on page load
        window.onload = function() {
            const savedProfile = localStorage.getItem('farmerProfile');
            if (savedProfile) {
                const profile = JSON.parse(savedProfile);
                document.getElementById('name').value = profile.name;
                document.getElementById('contact').value = profile.contact;
                document.getElementById('location').value = profile.location;
                document.getElementById('bio').value = profile.bio;
                document.getElementById('profile-pic').src = profile.profilePic;
            }
        };
    </script>
</body>
</html>
