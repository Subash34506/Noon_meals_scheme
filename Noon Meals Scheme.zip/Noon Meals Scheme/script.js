const currentUrl = window.location.pathname.split('/').pop();

        // Get all navigation links
        const navLinks = document.querySelectorAll('.nav-links a');

        // Loop through links to match the URL and add the 'active' class
        navLinks.forEach(link => {
            if (link.getAttribute('href') === currentUrl) {
                link.classList.add('active');
            }
        });
        document.addEventListener("scroll", function () {
            const rulesSection = document.querySelector(".rules");
            const sectionPosition = rulesSection.getBoundingClientRect();
            const windowHeight = window.innerHeight;
          
            if (sectionPosition.top <= windowHeight - 100) {
              rulesSection.classList.add("visible");
              const title = rulesSection.querySelector("h1");
              title.style.visibility = "visible"; // Ensure typing effect for title
              const listItems = rulesSection.querySelectorAll("li");
              listItems.forEach((item, index) => {
                item.style.visibility = "visible";
                item.style.animationDelay = `${index * 0.2}s`; // Staggered animation
              });
            }
          });
         
          document.getElementById('profile-pic-upload').addEventListener('change', function(event) {
              const file = event.target.files[0];
              if (file) {
                  const reader = new FileReader();
                  reader.onload = function(e) {
                      document.getElementById('profile-pic').src = e.target.result;
                  };
                  reader.readAsDataURL(file);
              }
          });
  
          document.getElementById('farmerProfileForm').addEventListener('submit', function(event) {
              event.preventDefault();
  
              const name = document.getElementById('name').value;
              const contact = document.getElementById('contact').value;
              const location = document.getElementById('location').value;
              const bio = document.getElementById('bio').value;
              const profilePic = document.getElementById('profile-pic').src;
  
              const farmerProfile = {
                  name,
                  contact,
                  location,
                  bio,
                  profilePic
              };
  
              // Save farmer profile to localStorage (or any backend if applicable)
              localStorage.setItem('farmerProfile', JSON.stringify(farmerProfile));
  
              alert('Profile saved successfully!');
          });
  
          // Load saved profile on page load
          window.onload = function() {
              const savedProfile = localStorage.getItem('farmerProfile');
              if (savedProfile) {
                  const profile = JSON.parse(savedProfile);
                  document.getElementById('name').value = profile.name;
                  document.getElementById('contact').value = profile.contact;
                  document.getElementById('location').value = profile.location;
                  document.getElementById('bio').value = profile.bio;
                  document.getElementById('profile-pic').src = profile.profilePic;
              }
          };
    
          